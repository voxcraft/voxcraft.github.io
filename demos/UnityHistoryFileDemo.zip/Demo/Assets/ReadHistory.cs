﻿using System;
using System.Xml;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
public class ReadHistory : MonoBehaviour
{
    public string URL;
    public GameObject Robot;
    GameObject Parent;
    public float PlaySpeed = 0.7f;
    public float GlobalScale = 1; // equavalent to use centimeter as measurement.
    public float VoxelSize = 0.9f;
    string history_content; // big string buffer contains the whole history file.
    ArrayList history_lines; // [string] big buffer contains lines of non-zero length.
    float ground_offset = 0.001f; // default voxel_size, will be override by settings.
    float rescale = 1f; // default rescale, will be override by settings.
    Dictionary<string, Material> materials = new Dictionary<string, Material>(); // different materials, i.e. different colors.
    ArrayList cubes = new ArrayList(); // [GameObject] all the cubes in the scene.
    bool initialized = false;
    const float sqrt3 = 1.732f;
    void Start()
    {
        if (URL.Length == 0)
        {
            // If there's no URL, here is the default.
            // However, if you want to export the animation to the web, you need to upload the history file, because the browser won't let user to fetch files from a different website.
            URL = "http://www.uvm.edu/~sliu1/voxcraft/history/m805.history";
        }
        StartCoroutine(LoadFromURI(URL));
    }
    void Update()
    {
        DrawRobot();
    }
    IEnumerator LoadFromURI(string uri)
    {
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
            // Request and wait for the desired page.
            yield return webRequest.SendWebRequest();

            string[] pages = uri.Split('/');
            int page = pages.Length - 1;

            if (webRequest.isNetworkError)
            {
                Debug.Log(pages[page] + ": Error: " + webRequest.error);
            }
            else
            {
                // Read all contents into memory buffer
                history_content = webRequest.downloadHandler.text;
                Debug.Log(history_content.Length);
                history_lines = new ArrayList();
                string[] lines = history_content.Split(new[] { '\r', '\n' });
                foreach (string line in lines)
                {
                    if (line.Length > 0)
                    { // skip empty lines
                        history_lines.Add(line);
                    }
                }
                ReadSettings();
                initialized = true;
            }
        }
    }
    void ReadSettings()
    {
        string prefix = "{{{setting}}}";
        foreach (string line in history_lines)
        {
            if (line.Length > prefix.Length)
            {
                if (line.Substring(0, prefix.Length).Equals(prefix))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(line.Substring(prefix.Length));
                    string tagname = doc.FirstChild.Name;
                    string value = doc.FirstChild.InnerText;
                    if (tagname.Equals("voxel_size"))
                    {
                        ground_offset = float.Parse(value) * GlobalScale / 2;
                        Debug.Log("ground_offset" + ground_offset);
                    }
                    else if (tagname.Equals("rescale"))
                    {
                        rescale = float.Parse(value) * GlobalScale;

                    }
                    else if (tagname.Equals("matcolor"))
                    {
                        string matid = doc.GetElementsByTagName("id")[0].InnerText;
                        float r = float.Parse(doc.GetElementsByTagName("r")[0].InnerText);
                        float g = float.Parse(doc.GetElementsByTagName("g")[0].InnerText);
                        float b = float.Parse(doc.GetElementsByTagName("b")[0].InnerText);
                        float a = float.Parse(doc.GetElementsByTagName("a")[0].InnerText);
                        Material m = new Material(Shader.Find("Custom/Voxel"));
                        m.SetColor("_Color", new Color(r, g, b, a));
                        materials.Add(matid, m);
                        Debug.Log("Add Material." + matid);
                    }
                }
            }
            if (line.Substring(0, 1).Equals("<"))
            {
                break;
            }
        }
    }
    // Update is called once per frame
    void DrawRobot()
    {
        if (initialized) // Only update when initialization is done
        {
            foreach (GameObject cube in cubes)
            {
                Destroy(cube);
            }
            if (Parent)
            {
                Destroy(Parent);
            }
            Parent = new GameObject();

            float current_time = Time.time / Time.fixedDeltaTime * PlaySpeed;
            // cursor, current_line: which frame we are drawing.
            int cursor = ((int)current_time) % history_lines.Count;
            string current_line = (string)history_lines[cursor];
            // Get rid of <<<>>>
            current_line = Regex.Replace(current_line, "<<<[^<>]*>>>", "");
            // Draw cubes
            string[] items = current_line.Split(new string[] { ";" }, StringSplitOptions.None);
            for (int i = 0; i < items.Length; i++)
            {
                string item = items[i];
                string[] pp = item.Split(new string[] { "," }, StringSplitOptions.None);
                if (pp.Length >= 15)
                {
                    // Create a Primitive: Cube
                    GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    cubes.Add(cube);
                    cube.transform.parent = Parent.transform;
                    // Set Cube's material
                    Renderer rend = cube.GetComponent<Renderer>();
                    rend.material = materials[pp[13]];
                    // Set Cube's position (+ground_offset) and rotation and size (local scale)
                    cube.transform.position = new Vector3(float.Parse(pp[0]), float.Parse(pp[2]), float.Parse(pp[1])) * rescale + new Vector3(0f, ground_offset, 0f);
                    cube.transform.rotation = Quaternion.AngleAxis(-float.Parse(pp[3]), new Vector3(float.Parse(pp[4]), float.Parse(pp[6]), float.Parse(pp[5])));
                    Vector3 vox_size = new Vector3((float.Parse(pp[10]) - float.Parse(pp[7])), (float.Parse(pp[11]) - float.Parse(pp[8])), (float.Parse(pp[12]) - float.Parse(pp[9])));
                    cube.transform.localScale = vox_size / sqrt3 * rescale * VoxelSize * 2;
                    Debug.Log("cube.transform.localScale" + cube.transform.localScale);
                }
            }
            // Move the whole robot to where we want it to be
            Parent.transform.position = Robot.transform.position;
            Parent.transform.rotation = Robot.transform.rotation;
        }
    }
}
